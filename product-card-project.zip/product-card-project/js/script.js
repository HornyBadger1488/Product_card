const cartButton = document.querySelector("#add-to-cart");
const wishlistButton = document.querySelector("#wishlist");
const wishlistLabel = document.querySelector("#wishlist-label");
const statusMessage = document.querySelector("#status-message");

cartButton.addEventListener("click", () => {
  statusMessage.textContent = "Added to cart!";
});

wishlistButton.addEventListener("click", () => {
  const isSaved = wishlistButton.getAttribute("aria-pressed") === "true";
  wishlistButton.setAttribute("aria-pressed", String(!isSaved));
  wishlistLabel.textContent = isSaved ? "Wishlist" : "Added to wishlist";
  statusMessage.textContent = isSaved
    ? "Removed from wishlist."
    : "Saved to wishlist.";
});
